#ifndef PASSCLASS_H
#define PASSCLASS_H

#include "Utility/cpputility.h"

class KeepPass
{
public:
    void add_pass(const char* key)
    {}

    void remove_pass(const char* key)
    {}

    void print_pass(const char* key)
    {}
};

#endif